/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.customermanagementsystem;

public class Report {
    private String category;
    private float total_sales;
    
    // Constructor, getters, and setters
    public Report() {}

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public float getTotalSales() {
        return total_sales;
    }

    public void setTotalSales(float total_sales) {
        this.total_sales = total_sales;
    }
    
}
